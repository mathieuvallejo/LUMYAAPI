import jwt from'jsonwebtoken';
import  model from'../models/user.js';

const JWT_SECRET = process.env.JWT;

async function authByToken(req, res, next) {
  try {
    const authHeader = req.headers?.authorization;
    const token = (authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null)
      ?? req.cookies?.access_token;
    if (!token) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await model.selectById(decoded.id);
    if (!user) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  } catch {
    res.status(403).json({ error: 'Invalid token' });
  }
}

export { authByToken };
